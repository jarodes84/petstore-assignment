# Selenium

# Time till the next command is executed
SELENIUM_DELAY = 2

# How long a "Wait Until ..." command should wait until test is declared timeout-failed
SELENIUM_TIMEOUT = 30

# Browser to webdrive on
BROWSER = "chrome"

# Variables
SERVER = "localhost"
PORT = "3000"
PETS_URL = "http://" + SERVER + ":" + PORT
